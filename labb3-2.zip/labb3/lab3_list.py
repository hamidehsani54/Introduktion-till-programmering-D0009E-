 #funktionen för att lägga till ord
def add_word(word_list, words_discribe):
   word_to_add=input("vad vill du lägga till?")
   if word_to_add not in word_list:
       word_list.append(word_to_add)
       describe_of_word=(input("beskriv ditt ord"))
       words_discribe.append(describe_of_word)
   else:
       print('Ordet finns redan')

#funktionen som kollar upp
def lookup(word_list, words_discribe):
    word=input("Välj ett ord från ordboken")
    #om ordet finns in word_list
    if word in word_list:
        print(words_discribe[word_list.index(word)])

    #om ordet inte finns i word_list
    else:
        print('Ordet hittades inte ')

#funktionen tar bort
def delete(word_list, words_discribe):
    question_to_delete=input("vill du ta bort sista inputen? j eller n")
    if question_to_delete=='j':
        word_list.remove(word_list[0])
        words_discribe.remove(words_discribe[0])
        print(words_discribe, word_list)
    if question_to_delete=='n':
        print("uppfattat")
        return word_list, words_discribe
#exit funktionen
def exit():
    quit()


#main meny
def meny():
    #listor
    word_list=[]
    words_discribe=[]
    while True:

            #alternativs frågan
            question=input("lägg till ord: 1\nKolla upp: 2\nradera: 3\nAvsluta: 4  ")

            #om alternativ frågan blir 1 då kallar den pp funktionen add_word
            if question=='1':
                add_word(word_list, words_discribe)

            #om man väljar 2 då kallar den på funktionen lookup
            if question=='2':
                lookup(word_list, words_discribe)

            # #om valet blir 3 då kallar den på funktionen delete
            elif question=='3':
                delete(word_list, words_discribe)



            # om man valde fyra då kallar den på funktionen exit och avslutar programmet.
            elif question=='4':
                exit()



meny()

