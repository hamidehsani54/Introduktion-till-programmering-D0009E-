def bounces():
            which=input("iteration eller rekursion")
            if which=='rekursion':
                #bounce med hjälp av rekursion
                tal=int(input("ett tal"))
                def bounce(tal):
                    print(tal)
                    if tal:
                        bounce(tal-1)
                        print(tal)
                bounce(tal)

            if which=='iteration':
                #bounce med hjälp av iterativ
                tal=int(input("skriv ett tal"))
                def bounce2(tal):
                    for n in range(tal,0,-1):
                        print(n)

                    for x in range(0, tal+1, +1):
                        print(x)

                bounce2(tal)

def tvarsummas():
        if which_one=='tvarsumma':
            #tvärsumma uppgiftern med hjälp av iterativ funktion
            which=input("iteration eller rekurtion")
            if which=='iteration':
                tal=int(input("tal"))
                def tvarsumma(tal):
                    n = 0
                    while tal:
                        n += tal % 10
                        tal=tal//10
                    print(n)
                tvarsumma(tal)


            #tvärsumma uppgiftern med hjälp av rekursiv funktion
            if which=='rekurtion':
                y=int(input("tal"))
                def tvarsumman2(y):
                    s=0
                    if y==0:
                        return 0
                    else:
                        s = (y % 10) + int(tvarsumman2(y//10))
                        return s

                print(tvarsumman2(y))
def derivata():
        import math
        #test funktion
        def f1(x):
            return x**2-1

        #f är förädnringen
        def derivative(f, x, h):
            k = (1/(2*h)) * ((f(x+h)- f(x-h)))
            return k

        #lutningen
        print("funktions lutningen är: ",derivative(math.sin, 2*math.pi, 0.00001))
        print("testet för x=-3 och h=0.00001 blir det: ", derivative(f1, -3, 0.00001))

        #visar hur stor är skillnaden på x-leden
        def dx(f, x):
            return abs(0-f(x))

        #f är funktions nollställe
        #x0 är sökningens starvärde
        #h är noggranhet
        def solve(f, x0, h):
            #skillnaden i x-leden mellan två iterationer
            d = dx(f, x0)
            while d>h:
                x0 = x0 - f(x0)/derivative(f, x0, 0.00001)
                d = dx(f, x0)
            print("söknings nollvärde för y: ",x0)

        solve(f1, 7, 0.05)



while True:
    which_one=input('vilken program vill du köra: bounce \ntvarsumma\nderivatan\neller vill du avsluta?')

    if which_one=='bounce':
            bounces()
    if which_one=='tvarsumma':
        tvarsummas()
    if which_one=='derivatan':
        derivata()

    if which_one=='avsluta':
        quit()
