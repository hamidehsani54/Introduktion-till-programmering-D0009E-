 #funktionen för att lägga till ord
def add_word(ordbook):
   word_to_add=input("vad vill du lägga till?")
   #om ordet finns inte redan med
   if word_to_add not in ordbook:
        describe_of_word=(input("beskriv ditt ord"))
        ordbook[word_to_add]=[describe_of_word]
        return word_to_add, describe_of_word
   #om ordet finns redan med
   else:
       print('Ordet finns redan')

#funktionen som kollar upp
def lookup(ordbook):
    lookup_word=input("Välj ett ord från ordboken")
    if lookup_word not in ordbook:
        print('ordet hittades inte')
    else:
        for word_to_add, describe_of_word in ordbook.items():
            #om ordet hittades i ordboken
            if word_to_add==lookup_word:
                print(word_to_add, ':', describe_of_word)
                #om ordet inte hittades i ordboken




#exit funktionen
def exit():
    quit()


#main meny
def meny():
    #dictionary
    ordbok={}
    while True:

            #alternativs frågan
            question=input("lägg till ord: 1\nKolla upp: 2\nAvsluta: 3  ")

            #om alternativ frågan blir 1 då kallar den pp funktionen add_word
            if question=='1':
                add_word(ordbok)

            #om man väljar 2 då kallar den på funktionen lookup
            if question=='2':
                lookup(ordbok)


            # om man valde fyra då kallar den på funktionen exit och avslutar programmet.
            elif question=='3':
                exit()


meny()

