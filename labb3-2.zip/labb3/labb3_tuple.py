#funktionen som lägger till ord
def addword(tuple_list):
    word_to_add=input("vad vill du lägga till?")

    #kollar om ordet finns redan med eller inte
    for isInList in tuple_list:
        if isInList[0]==word_to_add:
            print('finns redan med')
            return

    #om det finns inte med
    if word_to_add not in tuple_list:
        describe_of_word=(input("beskriv ditt ord"))
        tuple_list.append(tuple((word_to_add, describe_of_word)))

#funktionen för att kolla upp
def lookupp(tuple_list):
  word=input("välj ett ord från listan")
  for word_to_add in tuple_list:
    #om ordet hittades i tuple listan
    if word_to_add[0] == word:
      print(word_to_add[1])
      return
#om ordet hittades inte i tuple listan
  print('ordet hittades inte')

#funktionen för att quita programmet
def exit():

    quit()

def meny():
    #tuple listan
    tuple_list=[]

    while (True):
        #huvudfrågan
       question=input("lägg till ord: 1\nKolla upp: 2\nAvsluta: 3")
        #om man väljar ett så kör den addword funktionen
       if question=='1':
        (addword(tuple_list))
        #om valet blir 2 då kör den funktionen lookipp
       if question=='2':
        lookupp(tuple_list)
        #om valet blir tre då kör den quit funktionen
       if question=='3':
        exit()
meny()
