import math
#test funktion
def f1(x):
    return x*2-1

#f är funktionen
#x är punkten vi kollar på
#h är nogrannheten
def derivative(f, x, h):
    k = (1/(2*h)) * ((f(x+h)- f(x-h)))
    return k

#lutningen
print("funktions lutningen är: ",derivative(math.sin, 2*math.pi, 0.00001))
print("testet för x=-3 och h=0.00001 blir det: ", derivative(f1, -3, 0.00001))

#dx är en funktion som ger ut hur långt ifrån x-axeln funktionen är i punkten x, alltså ju mindre värden den ger ut destå närmare är den. 0=nollställe
def dx(f, x):
    return abs(0-f(x))

#f är funktionen
#x0 är sökningens starvärde
#h är noggranhet
def solve(f, x0, h):
    #skillnaden i x-leden mellan två iterationer
    d = dx(f, x0)
    while d>h:
        x0 = x0 - f(x0)/derivative(f, x0, 0.00001)
        d = dx(f, x0)
    print("söknings nollvärde för y: ",x0)

solve(f1, 7, 0.05)
