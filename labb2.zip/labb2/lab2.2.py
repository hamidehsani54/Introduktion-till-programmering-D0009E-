#bounce med hjälp av iterativ
tal=int(input("skriv ett tal"))
def bounce2(tal):

    for n in range(tal,0,-1):
        print(n)

    for x in range(0, tal+1, +1):
        print(x)

bounce2(tal)

print(("==")*30)
