#bounce med hjälp av rekursion
tal=int(input("ett tal"))
def bounce(tal):
    print(tal)
    if tal:
        bounce(tal-1)
        print(tal)
bounce(tal)
