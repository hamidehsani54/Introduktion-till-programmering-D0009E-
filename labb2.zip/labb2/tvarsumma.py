#tvärsumma uppgiftern med hjälp av iterativ funktion
tal=int(input("tal"))
def tvarsumma(tal):
    n = 0
    while tal:
        n += tal % 10
        tal=tal//10
    print(n)
tvarsumma(tal)

print("==="*40)




#tvärsumma uppgiftern med hjälp av rekursiv funktion
y=int(input("tal"))
def tvarsumman2(y):
    s=0
    if y==0:
        return 0
    else:
        s = (y % 10) + int(tvarsumman2(y//10))
        return s

print(tvarsumman2(y))
